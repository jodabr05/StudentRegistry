<?php
$user = 'root';
$pass = '';
$db = 'registeredstudents';

$db = new mysqli('localhost', $user, $pass, $db) or die("Sorry... keep up the hard work buddy.");
	$course = $_POST['course'];
	$user = $_POST['user'];

	$conn = new mysqli('localhost','root','','registeredstudents');
	if($conn->connect_error){
		die('Connection Failed : '. $conn->connect_error);
	}else{
        $count_res = mysqli_fetch_all(
            mysqli_query($conn, "select * from active_student_roster asr join active_courses ac on asr.active_course_id = ac.course_id where asr.active_course_id = $course")
        );
        $capacity_query = mysqli_query($conn, "select * from active_courses where active_course_id = $course");
        $capacity = mysqli_fetch_array($capacity_query)['capacity'];
        $count = sizeof($count_res);
        if($capacity > $count){
            $stmt = $conn->prepare("Insert into active_student_roster(student_id, active_course_id)
			values(?, ?)");
			$stmt->bind_param("ss", $user, $course);
			$stmt->execute();
			echo "Enrollment Successful";
			$stmt->close();
            mysqli_query($conn, "delete from course_waitlist where active_course_id = $course AND student_id = $user;");
            mysqli_query($conn, "delete from pending_notifications where active_course_id = $course AND student_id = $user;");
			$conn->close();
        } else {
            $stmt = $conn->prepare("Insert into course_waitlist(student_id, active_course_id)
			values(?, ?)");
			$stmt->bind_param("ss", $user, $course);
			$stmt->execute();
			echo "Waitlisting Successful";
			$stmt->close();
			$conn->close();
        }
		
	}

    header("Location: userprofile.php");

?>

$conn->prepare("select * from active_student_roster asr join active_courses ac on asr.active_course_id = ac.course_id where asr.active_course_id = ?");
			$active_count_sql->bind_param("s", $course);