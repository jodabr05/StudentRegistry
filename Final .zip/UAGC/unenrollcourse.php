<?php
$user = 'root';
$pass = '';
$db = 'registeredstudents';

$db = new mysqli('localhost', $user, $pass, $db) or die("Sorry... keep up the hard work buddy.");
	$course = $_POST['course'];
	$user = $_POST['user'];


	$conn = new mysqli('localhost','root','','registeredstudents');
	if($conn->connect_error){
		die('Connection Failed : '. $conn->connect_error);
	}else{
		$stmt = $conn->prepare("Delete from active_student_roster where student_id = ? AND active_course_id = ?");
        $stmt->bind_param("ss", $user, $course);
        $stmt->execute();
        echo "Unenrollment Successful";
        $stmt->close();

        $waitlist_query = mysqli_query($conn, "Select student_id, active_course_id, added_at from course_waitlist where active_course_id = $course order by added_at limit 1");
        $waiting_student = mysqli_fetch_array($waitlist_query);
        if($waiting_student){
            $id = $waiting_student["student_id"];
            $course = $waiting_student["active_course_id"];
            mysqli_query($conn, "Insert into pending_notifications (student_id, active_course_id) VALUES($id, $course);");
        }
	}

    header("Location: userprofile.php");

?>
